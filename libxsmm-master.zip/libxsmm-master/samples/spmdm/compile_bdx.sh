#!/bin/sh

make clean; make AVX=2 OMP=1 OPT=3
